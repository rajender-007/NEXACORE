class CarbonEstimator:
    """
    Estimates carbon emissions and cost savings from energy reduction.
    Based on average global grid carbon intensity.
    """

    def __init__(self, carbon_intensity_kg_per_kwh=0.475, electricity_cost_per_kwh=0.12):
        # Average global carbon intensity: ~475g CO2 per kWh
        self.carbon_intensity = carbon_intensity_kg_per_kwh
        self.electricity_cost = electricity_cost_per_kwh

    def estimate(self, power_saved_watts, hours=24):
        """Estimate daily carbon and cost savings from reduced power."""
        energy_saved_kwh = (power_saved_watts * hours) / 1000
        carbon_saved_kg = energy_saved_kwh * self.carbon_intensity
        cost_saved_usd = energy_saved_kwh * self.electricity_cost
        annual_carbon_kg = carbon_saved_kg * 365
        annual_cost_usd = cost_saved_usd * 365
        trees_equivalent = annual_carbon_kg / 21  # avg tree absorbs ~21kg CO2/year
        return {
            'daily_energy_saved_kwh': round(energy_saved_kwh, 2),
            'daily_carbon_saved_kg': round(carbon_saved_kg, 2),
            'daily_cost_saved_usd': round(cost_saved_usd, 2),
            'annual_carbon_saved_kg': round(annual_carbon_kg, 1),
            'annual_cost_saved_usd': round(annual_cost_usd, 2),
            'trees_equivalent_per_year': round(trees_equivalent, 1)
        }

    def get_emission_label(self, carbon_kg_per_day):
        if carbon_kg_per_day < 5:
            return "🟢 Low Emissions"
        elif carbon_kg_per_day < 15:
            return "🟡 Moderate Emissions"
        else:
            return "🔴 High Emissions"
