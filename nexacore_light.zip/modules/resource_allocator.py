import numpy as np

class ResourceAllocator:
    def __init__(self, total_cpu_cores=64, total_gpu_units=8, max_power_budget=1200):
        self.total_cpu_cores = total_cpu_cores
        self.total_gpu_units = total_gpu_units
        self.max_power_budget = max_power_budget
        self.cpu_power_per_core = 8.0
        self.gpu_power_per_unit = 60.0
        self.base_power = 150.0
        self.min_cpu_cores = 4
        self.min_gpu_units = 1
        self.sla_headroom = 0.15

    def allocate(self, predicted_cpu_pct, current_gpu_pct=None):
        if current_gpu_pct is None:
            current_gpu_pct = predicted_cpu_pct * 0.7
        target_cpu = min(predicted_cpu_pct * (1 + self.sla_headroom), 100)
        target_gpu = min(current_gpu_pct * (1 + self.sla_headroom), 100)
        cpu_cores_needed = max(self.min_cpu_cores, int(np.ceil(self.total_cpu_cores * target_cpu / 100)))
        gpu_units_needed = max(self.min_gpu_units, int(np.ceil(self.total_gpu_units * target_gpu / 100)))
        estimated_power = self.base_power + cpu_cores_needed * self.cpu_power_per_core + gpu_units_needed * self.gpu_power_per_unit
        if estimated_power > self.max_power_budget:
            scale = (self.max_power_budget - self.base_power) / (cpu_cores_needed * self.cpu_power_per_core + gpu_units_needed * self.gpu_power_per_unit)
            cpu_cores_needed = max(self.min_cpu_cores, int(cpu_cores_needed * scale))
            gpu_units_needed = max(self.min_gpu_units, int(gpu_units_needed * scale))
            estimated_power = self.base_power + cpu_cores_needed * self.cpu_power_per_core + gpu_units_needed * self.gpu_power_per_unit
        static_cpu_cores = int(self.total_cpu_cores * 0.80)
        static_gpu_units = int(self.total_gpu_units * 0.80)
        static_power = self.base_power + static_cpu_cores * self.cpu_power_per_core + static_gpu_units * self.gpu_power_per_unit
        power_saved = static_power - estimated_power
        efficiency_gain = round((power_saved / static_power) * 100, 1) if static_power > 0 else 0
        return {
            'cpu_cores_allocated': cpu_cores_needed,
            'gpu_units_allocated': gpu_units_needed,
            'cpu_utilization_pct': round(cpu_cores_needed / self.total_cpu_cores * 100, 1),
            'gpu_utilization_pct': round(gpu_units_needed / self.total_gpu_units * 100, 1),
            'estimated_power_watts': round(estimated_power, 1),
            'static_power_watts': round(static_power, 1),
            'power_saved_watts': round(max(power_saved, 0), 1),
            'efficiency_gain_pct': max(efficiency_gain, 0),
            'sla_compliant': estimated_power <= self.max_power_budget
        }

    def get_allocation_schedule(self, forecast_df):
        results = []
        for _, row in forecast_df.iterrows():
            alloc = self.allocate(row['predicted_cpu'])
            alloc['timestamp'] = row['timestamp']
            alloc['predicted_cpu'] = row['predicted_cpu']
            results.append(alloc)
        return results
