import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
import warnings
warnings.filterwarnings('ignore')

class WorkloadPredictor:
    """
    Time-series workload forecasting model.
    Uses lag features + Ridge Regression to predict future CPU/GPU demand.
    """

    def __init__(self, look_back=12, forecast_steps=8):
        self.look_back = look_back
        self.forecast_steps = forecast_steps
        self.scaler = MinMaxScaler()
        self.model = Ridge(alpha=1.0)
        self.is_trained = False

    def _create_features(self, series):
        X, y = [], []
        for i in range(self.look_back, len(series) - self.forecast_steps):
            features = list(series[i - self.look_back:i])
            features.append(np.mean(series[i - self.look_back:i]))
            features.append(np.std(series[i - self.look_back:i]))
            X.append(features)
            y.append(series[i:i + self.forecast_steps])
        return np.array(X), np.array(y)

    def train(self, df):
        cpu_series = df['cpu_usage'].values
        scaled = self.scaler.fit_transform(cpu_series.reshape(-1, 1)).flatten()
        X, y = self._create_features(scaled)
        self.model.fit(X, y)
        self.is_trained = True
        y_pred = self.model.predict(X)
        mae = mean_absolute_error(y[:, 0], y_pred[:, 0])
        r2 = r2_score(y[:, 0], y_pred[:, 0])
        return {'mae': round(mae, 4), 'r2': round(r2, 4)}

    def predict(self, recent_values):
        if not self.is_trained:
            raise ValueError("Model not trained yet.")
        scaled = self.scaler.transform(np.array(recent_values[-self.look_back:]).reshape(-1, 1)).flatten()
        features = list(scaled) + [np.mean(scaled), np.std(scaled)]
        pred_scaled = self.model.predict([features])[0]
        pred = self.scaler.inverse_transform(pred_scaled.reshape(-1, 1)).flatten()
        return np.clip(pred, 0, 100).tolist()

    def get_forecast_df(self, df, interval_minutes=15):
        recent = df['cpu_usage'].values[-self.look_back:]
        predictions = self.predict(recent)
        last_time = df['timestamp'].iloc[-1]
        future_times = [last_time + pd.Timedelta(minutes=interval_minutes * (i + 1)) for i in range(len(predictions))]
        return pd.DataFrame({'timestamp': future_times, 'predicted_cpu': np.round(predictions, 2)})
