import sys, os, time, random
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime

from data.generate_data import generate_workload_data, get_live_snapshot
from models.predictor import WorkloadPredictor
from modules.resource_allocator import ResourceAllocator
from modules.carbon_estimator import CarbonEstimator

st.set_page_config(page_title="NEXACORE", page_icon="⚡", layout="wide", initial_sidebar_state="collapsed")

# ══════════════════════════════════════════════════════════════════════════════
# STYLES  (light cloud professional theme)
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');

*, *::before, *::after { box-sizing: border-box; }
html, body, [class*="css"] { font-family: 'Outfit', sans-serif; }

/* ── CLOUD BACKGROUND ── */
.stApp {
  background: #f0f4f8;
  background-image:
    radial-gradient(ellipse 140% 70% at 5%  0%,  rgba(186,230,255,0.75) 0%, transparent 55%),
    radial-gradient(ellipse 100% 60% at 95% 5%,  rgba(221,214,254,0.55) 0%, transparent 50%),
    radial-gradient(ellipse  80% 50% at 50% 50%, rgba(255,255,255,0.90) 0%, transparent 60%),
    radial-gradient(ellipse  70% 40% at 20% 90%, rgba(186,230,255,0.40) 0%, transparent 50%);
}
.main .block-container { padding:1rem 1.8rem 2rem !important; max-width:100% !important; }
#MainMenu, footer, header { visibility:hidden !important; }
.stDeployButton { display:none !important; }

/* ── HEADER ── */
.hdr {
  display:flex; align-items:center; justify-content:space-between;
  padding:18px 28px;
  background:rgba(255,255,255,0.88);
  border:1px solid rgba(186,230,255,0.7);
  border-radius:22px; margin-bottom:18px;
  backdrop-filter:blur(20px);
  box-shadow:0 2px 30px rgba(99,179,237,0.12), 0 1px 0 rgba(255,255,255,1) inset;
}
.hdr-logo {
  font-family:'Outfit',sans-serif; font-weight:800; font-size:1.9rem;
  background:linear-gradient(130deg,#0284c7 0%,#7c3aed 55%,#0891b2 100%);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent;
  letter-spacing:-1.5px; line-height:1;
}
.hdr-sub {
  font-family:'JetBrains Mono',monospace; font-size:0.6rem;
  color:#94a3b8; letter-spacing:2px; text-transform:uppercase; margin-top:4px;
}
.hdr-badge {
  display:flex; align-items:center; gap:8px;
  background:rgba(16,185,129,0.09); border:1px solid rgba(16,185,129,0.28);
  color:#059669; font-family:'JetBrains Mono',monospace;
  font-size:0.62rem; padding:7px 16px; border-radius:30px; letter-spacing:1.5px;
}
.hdr-pip {
  width:7px; height:7px; background:#10b981; border-radius:50%;
  box-shadow:0 0 9px #10b981; animation:pip 1.6s ease-in-out infinite;
}
@keyframes pip{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.15;transform:scale(2)}}
.hdr-clock { font-family:'JetBrains Mono',monospace; font-size:2.1rem; font-weight:600; color:#0f172a; letter-spacing:3px; text-align:right; }
.hdr-date  { font-family:'JetBrains Mono',monospace; font-size:0.6rem; color:#94a3b8; letter-spacing:2px; text-transform:uppercase; text-align:right; margin-top:4px; }

/* ── NAV ── */
.nx-nav {
  display:flex; gap:4px; padding:5px;
  background:rgba(255,255,255,0.75); border:1px solid rgba(186,230,255,0.55);
  border-radius:16px; margin-bottom:18px;
  box-shadow:0 1px 10px rgba(99,179,237,0.08);
}
.nx-nb {
  flex:1; text-align:center; padding:10px 4px; border-radius:11px;
  font-family:'JetBrains Mono',monospace; font-size:0.65rem; letter-spacing:1.5px;
  color:#94a3b8; text-transform:uppercase; border:1px solid transparent; transition:all .2s;
}
.nx-nb.active {
  background:rgba(255,255,255,0.98); color:#0284c7;
  border-color:rgba(147,197,253,0.7);
  box-shadow:0 2px 14px rgba(14,165,233,0.14);
}

/* ── KPI CARDS ── */
.kpi {
  background:rgba(255,255,255,0.92);
  border:1px solid rgba(226,232,240,0.9);
  border-radius:18px; padding:22px 16px; text-align:center;
  position:relative; overflow:hidden;
  box-shadow:0 1px 14px rgba(0,0,0,0.05);
  transition:transform .25s ease, box-shadow .25s ease;
}
.kpi:hover { transform:translateY(-4px); box-shadow:0 10px 36px rgba(0,0,0,0.09); }
.kpi-top  { position:absolute; top:0; left:0; right:0; height:3px; border-radius:18px 18px 0 0; }
.kpi-icon { font-size:1.5rem; margin-bottom:8px; }
.kpi-val  { font-family:'Outfit',sans-serif; font-weight:700; font-size:1.7rem; letter-spacing:-1px; line-height:1; margin:4px 0; }
.kpi-lbl  { font-family:'JetBrains Mono',monospace; font-size:0.57rem; color:#94a3b8; letter-spacing:2px; text-transform:uppercase; margin-top:6px; }
.kpi-dlt  { font-family:'JetBrains Mono',monospace; font-size:0.6rem; color:#10b981; margin-top:7px; }

.C-sky    .kpi-top { background:linear-gradient(90deg,#bae6fd,#38bdf8,#bae6fd); } .C-sky    .kpi-val { color:#0284c7; }
.C-green  .kpi-top { background:linear-gradient(90deg,#a7f3d0,#34d399,#a7f3d0); } .C-green  .kpi-val { color:#059669; }
.C-amber  .kpi-top { background:linear-gradient(90deg,#fde68a,#fbbf24,#fde68a); } .C-amber  .kpi-val { color:#d97706; }
.C-violet .kpi-top { background:linear-gradient(90deg,#ddd6fe,#a78bfa,#ddd6fe); } .C-violet .kpi-val { color:#7c3aed; }
.C-rose   .kpi-top { background:linear-gradient(90deg,#fecaca,#f87171,#fecaca); } .C-rose   .kpi-val { color:#dc2626; }
.C-teal   .kpi-top { background:linear-gradient(90deg,#99f6e4,#2dd4bf,#99f6e4); } .C-teal   .kpi-val { color:#0891b2; }

/* ── SECTION ── */
.sec {
  display:flex; align-items:center; gap:10px;
  font-family:'JetBrains Mono',monospace; font-size:0.62rem;
  color:#94a3b8; letter-spacing:2.5px; text-transform:uppercase;
  padding-bottom:12px; margin-bottom:16px;
  border-bottom:1.5px solid rgba(226,232,240,0.9);
}
.sec-bar { width:3px; height:16px; background:linear-gradient(180deg,#38bdf8,#8b5cf6); border-radius:2px; flex-shrink:0; }

/* ── PANEL ── */
.panel {
  background:rgba(255,255,255,0.92); border:1px solid rgba(226,232,240,0.9);
  border-radius:18px; padding:22px;
  box-shadow:0 1px 14px rgba(0,0,0,0.05);
}

/* ── PROGRESS ── */
.pb { margin-bottom:18px; }
.pb-row { display:flex; justify-content:space-between; margin-bottom:6px; }
.pb-lbl { font-family:'JetBrains Mono',monospace; font-size:0.62rem; color:#94a3b8; letter-spacing:1.5px; }
.pb-val { font-family:'JetBrains Mono',monospace; font-size:0.7rem; font-weight:600; }
.pb-track { height:6px; background:#f1f5f9; border-radius:4px; overflow:hidden; }
.pb-fill  { height:100%; border-radius:4px; transition:width 1.2s cubic-bezier(.4,0,.2,1); }
.pf-sky    { background:linear-gradient(90deg,#bae6fd,#0ea5e9); }    .pb-val.sky    { color:#0284c7; }
.pf-violet { background:linear-gradient(90deg,#ddd6fe,#8b5cf6); }    .pb-val.violet { color:#7c3aed; }
.pf-amber  { background:linear-gradient(90deg,#fef3c7,#f59e0b); }    .pb-val.amber  { color:#d97706; }
.pf-green  { background:linear-gradient(90deg,#a7f3d0,#10b981); }    .pb-val.green  { color:#059669; }

/* ── DB CARDS ── */
.dbc {
  background:rgba(255,255,255,0.92); border:1px solid rgba(226,232,240,0.9);
  border-radius:14px; padding:16px 18px; margin-bottom:8px;
  box-shadow:0 1px 8px rgba(0,0,0,0.04);
  transition:transform .2s, border-color .2s, box-shadow .2s;
}
.dbc:hover { transform:translateX(4px); border-color:#bae6fd; box-shadow:0 4px 18px rgba(14,165,233,0.1); }
.dbc-name { font-family:'JetBrains Mono',monospace; font-size:0.72rem; color:#0284c7; font-weight:600; margin-bottom:8px; }
.dbc-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:4px 12px; }
.dbc-cell { font-family:'JetBrains Mono',monospace; font-size:0.6rem; color:#475569; }
.dbc-cell b { color:#94a3b8; display:block; font-size:0.55rem; letter-spacing:1px; text-transform:uppercase; }
.st-on  { color:#059669 !important; font-weight:600; }
.st-stb { color:#d97706 !important; font-weight:600; }

/* ── CHAT ── */
.cw { margin-bottom:16px; }
.cm-b {
  background:rgba(255,255,255,0.95); border:1px solid #e2e8f0;
  border-radius:2px 16px 16px 16px; padding:12px 16px;
  display:inline-block; max-width:88%;
  font-size:0.86rem; line-height:1.7; color:#334155;
  box-shadow:0 1px 8px rgba(0,0,0,0.05);
}
.cm-u {
  background:linear-gradient(135deg,#0284c7,#0ea5e9);
  border-radius:16px 2px 16px 16px; padding:12px 16px;
  display:inline-block; max-width:80%;
  font-size:0.86rem; line-height:1.7; color:#fff;
  box-shadow:0 4px 18px rgba(14,165,233,0.3);
}
.cm-t { font-family:'JetBrains Mono',monospace; font-size:0.58rem; color:#cbd5e1; margin-top:4px; }

/* ── FEEDBACK ── */
.fbc {
  background:rgba(255,255,255,0.92); border:1px solid rgba(226,232,240,0.9);
  border-left:3px solid #38bdf8; border-radius:0 14px 14px 0;
  padding:14px 18px; margin-bottom:10px;
  box-shadow:0 1px 8px rgba(0,0,0,0.04);
  transition:border-left-color .2s, box-shadow .2s;
}
.fbc:hover { border-left-color:#10b981; box-shadow:0 4px 20px rgba(0,0,0,0.07); }
.fbc-user { font-family:'JetBrains Mono',monospace; font-size:0.7rem; color:#0284c7; font-weight:600; }
.fbc-text { font-size:0.85rem; color:#475569; margin-top:7px; line-height:1.6; }
.fbc-foot { font-family:'JetBrains Mono',monospace; font-size:0.58rem; color:#cbd5e1; margin-top:5px; }

/* ── BUTTONS ── */
.stButton > button {
  background:rgba(255,255,255,0.9) !important; border:1px solid #e2e8f0 !important;
  color:#64748b !important; border-radius:10px !important;
  font-family:'Outfit',sans-serif !important; font-size:0.78rem !important; font-weight:500 !important;
  box-shadow:0 1px 4px rgba(0,0,0,0.05) !important; transition:all .2s !important;
}
.stButton > button:hover {
  background:#eff6ff !important; border-color:#93c5fd !important;
  color:#0284c7 !important; box-shadow:0 3px 12px rgba(14,165,233,0.15) !important;
}
.stButton > button[kind="primary"] {
  background:linear-gradient(135deg,#eff6ff,#dbeafe) !important;
  border-color:#93c5fd !important; color:#0284c7 !important;
}
/* ── INPUTS ── */
.stTextInput > div > div > input,
.stTextArea  > div > div > textarea {
  background:rgba(255,255,255,0.9) !important; border:1px solid #e2e8f0 !important;
  border-radius:10px !important; color:#0f172a !important;
  font-family:'Outfit',sans-serif !important;
}
.stTextInput > div > div > input:focus,
.stTextArea  > div > div > textarea:focus {
  border-color:#93c5fd !important; box-shadow:0 0 0 3px rgba(147,197,253,0.2) !important;
}
label, [data-baseweb="form-control-label"] {
  font-family:'JetBrains Mono',monospace !important; font-size:0.6rem !important;
  letter-spacing:1.5px !important; text-transform:uppercase !important; color:#94a3b8 !important;
}
.stSelectbox > div > div {
  background:rgba(255,255,255,0.9) !important; border:1px solid #e2e8f0 !important;
  border-radius:10px !important; color:#0f172a !important;
}
/* ── METRICS ── */
[data-testid="stMetric"] {
  background:rgba(255,255,255,0.92); border:1px solid rgba(226,232,240,0.9);
  border-radius:14px; padding:14px !important; box-shadow:0 1px 8px rgba(0,0,0,0.04);
}
[data-testid="stMetricLabel"] { color:#94a3b8 !important; font-family:'JetBrains Mono',monospace !important; font-size:0.58rem !important; letter-spacing:1.5px !important; text-transform:uppercase !important; }
[data-testid="stMetricValue"] { color:#0284c7 !important; font-family:'Outfit',sans-serif !important; font-size:1.3rem !important; font-weight:700 !important; }
[data-testid="stMetricDelta"] { font-family:'JetBrains Mono',monospace !important; font-size:0.65rem !important; }
.stDataFrame { border:1px solid rgba(226,232,240,0.9) !important; border-radius:14px !important; }
::-webkit-scrollbar { width:4px; height:4px; }
::-webkit-scrollbar-track { background:#f8fafc; }
::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }
hr { border-color:#e2e8f0 !important; }
</style>

<script>
(function(){
  function pad(n){return String(n).padStart(2,'0');}
  function tick(){
    var el=document.getElementById('nx-clock');
    if(el){var d=new Date();el.textContent=pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds());}
  }
  setInterval(tick,1000); setTimeout(tick,50);
})();
</script>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# PLOTLY THEME  (light)
# ══════════════════════════════════════════════════════════════════════════════
_PL = dict(
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(248,250,252,0.8)',
    font=dict(family='JetBrains Mono', color='#94a3b8', size=9),
    margin=dict(t=28, b=28, l=8, r=8),
    xaxis=dict(showgrid=False, color='#cbd5e1', zeroline=False, tickfont=dict(size=8), tickcolor='#e2e8f0'),
    yaxis=dict(showgrid=True, gridcolor='rgba(226,232,240,0.8)', color='#cbd5e1', zeroline=False, tickfont=dict(size=8)),
    legend=dict(bgcolor='rgba(255,255,255,0.7)', orientation='h', y=1.16,
                font=dict(size=9), bordercolor='rgba(226,232,240,0.8)', borderwidth=1),
    hoverlabel=dict(bgcolor='#fff', bordercolor='#e2e8f0',
                    font=dict(family='JetBrains Mono', size=11, color='#0f172a')),
    hovermode='x unified',
)

def CH(h=320, **ov):
    d = {**_PL, 'height': h}
    d.update(ov)
    return d

# ── HTML helpers ──────────────────────────────────────────────────────────────
def kpi(icon, val, lbl, theme, delta=None):
    dh = f'<div class="kpi-dlt">▲ {delta}</div>' if delta else ''
    return f"""<div class="kpi {theme}">
      <div class="kpi-top"></div>
      <div class="kpi-icon">{icon}</div>
      <div class="kpi-val">{val}</div>
      <div class="kpi-lbl">{lbl}</div>
      {dh}
    </div>"""

def pbr(lbl, num, mx, fill, val_col, disp):
    pct = min(float(num)/float(mx)*100, 100)
    return f"""<div class="pb">
      <div class="pb-row">
        <span class="pb-lbl">{lbl}</span>
        <span class="pb-val {val_col}">{disp}</span>
      </div>
      <div class="pb-track"><div class="pb-fill {fill}" style="width:{pct:.1f}%"></div></div>
    </div>"""

def sec(title, ic='◈'):
    st.markdown(f'<div class="sec"><div class="sec-bar"></div>{ic} &nbsp; {title}</div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE
# ══════════════════════════════════════════════════════════════════════════════
def init():
    for k, v in {
        'page': 'DASHBOARD',
        'total_kwh': round(random.uniform(1400,1900),1),
        'total_co2': round(random.uniform(600,900),1),
        'uptime':    random.randint(800,2500),
        'live_hist': [],
        'chat': [{'role':'bot','text':'⚡ NEXACORE AI online.\n\nReal-time metrics loaded. Ask me:\ncpu · gpu · memory · power · co2 · cost · model · sla · database · tips\n\nType help for full list.','time':'NOW'}],
        'feedback': [
            {'user':'Arjun S.','rating':5,'text':'Cut our power bill by 30%. Prediction accuracy is outstanding.','dept':'Engineering','cat':'Energy Savings','time':'2h ago'},
            {'user':'Priya M.','rating':5,'text':'Carbon estimator is perfect for our sustainability reports.','dept':'Operations','cat':'Dashboard UI','time':'5h ago'},
            {'user':'Rahul K.','rating':4,'text':'Live analyzer is great. Deeper GPU metrics would be a plus.','dept':'Research','cat':'AI Features','time':'1d ago'},
        ],
    }.items():
        if k not in st.session_state:
            st.session_state[k] = v
init()

# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
with st.expander("⚙️  SYSTEM CONFIGURATION", expanded=False):
    c1,c2,c3,c4,c5,c6,c7 = st.columns(7)
    with c1: total_cpu      = st.slider("CPU Cores",   16,128,64,  step=8)
    with c2: total_gpu      = st.slider("GPU Units",    2, 16, 8)
    with c3: power_budget   = st.slider("Power (W)",  800,2000,1200,step=50)
    with c4: history_days   = st.slider("History (d)",  7,  60,30)
    with c5: forecast_steps = st.slider("Forecast",    4,  16, 8)
    with c6: carbon_int     = st.slider("CO₂ kg/kWh",0.2, 0.9,0.475,step=0.025)
    with c7: elec_cost      = st.slider("$/kWh",      0.05,0.30,0.12,step=0.01)

# ══════════════════════════════════════════════════════════════════════════════
# COMPUTE
# ══════════════════════════════════════════════════════════════════════════════
@st.cache_data(ttl=60)
def load(days, steps):
    df = generate_workload_data(days=days)
    p  = WorkloadPredictor(look_back=12, forecast_steps=steps)
    m  = p.train(df)
    f  = p.get_forecast_df(df)
    return df, m, f

df, model_m, fdf = load(history_days, forecast_steps)
alloc = ResourceAllocator(total_cpu_cores=total_cpu, total_gpu_units=total_gpu, max_power_budget=power_budget)
carb  = CarbonEstimator(carbon_intensity_kg_per_kwh=carbon_int, electricity_cost_per_kwh=elec_cost)
live  = get_live_snapshot()
cur   = alloc.allocate(live['cpu'], live['gpu'])
co2   = carb.estimate(cur['power_saved_watts'])
sched = alloc.get_allocation_schedule(fdf)

st.session_state['total_kwh'] += round(cur['power_saved_watts']*15/60/1000, 4)
st.session_state['total_co2'] += round(co2['daily_carbon_saved_kg']/96, 5)
st.session_state['live_hist'].append({
    'time': datetime.now().strftime('%H:%M:%S'),
    'cpu': live['cpu'], 'gpu': live['gpu'],
    'mem': live['memory'], 'power': live['power'],
    'saved': cur['power_saved_watts'],
})
if len(st.session_state['live_hist']) > 40:
    st.session_state['live_hist'] = st.session_state['live_hist'][-40:]
lh = pd.DataFrame(st.session_state['live_hist'])

# ══════════════════════════════════════════════════════════════════════════════
# HEADER  (live clock via JS)
# ══════════════════════════════════════════════════════════════════════════════
now = datetime.now()
st.markdown(f"""
<div class="hdr">
  <div>
    <div class="hdr-logo">NEXACORE</div>
    <div class="hdr-sub">AMD Slingshot &nbsp;·&nbsp; Energy-Aware DC Optimizer &nbsp;·&nbsp; A. Rajender Reddy</div>
  </div>
  <div class="hdr-badge"><span class="hdr-pip"></span> ALL SYSTEMS OPERATIONAL</div>
  <div>
    <div class="hdr-clock" id="nx-clock">{now.strftime('%H:%M:%S')}</div>
    <div class="hdr-date">{now.strftime('%A · %d %B %Y')}</div>
  </div>
</div>""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# NAVIGATION
# ══════════════════════════════════════════════════════════════════════════════
pages = ['DASHBOARD','LIVE ANALYZER','DATABASES','AI ASSISTANT','FEEDBACK']
nav_html = '<div class="nx-nav">'
for pg in pages:
    cls = 'nx-nb active' if st.session_state['page']==pg else 'nx-nb'
    nav_html += f'<div class="{cls}">{pg}</div>'
nav_html += '</div>'
st.markdown(nav_html, unsafe_allow_html=True)

nc = st.columns(len(pages))
for i,(col,pg) in enumerate(zip(nc,pages)):
    with col:
        if st.button(pg, key=f"n{i}", use_container_width=True,
                     type="primary" if st.session_state['page']==pg else "secondary"):
            st.session_state['page']=pg; st.rerun()

r1,r2,_ = st.columns([1,1,8])
with r1:
    if st.button("↺  Refresh", use_container_width=True):
        st.cache_data.clear(); st.rerun()
with r2:
    auto_ref = st.toggle("● Live (5s)", value=False)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE: DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
if st.session_state['page'] == 'DASHBOARD':

    sec("CUMULATIVE IMPACT", "⬡")
    ic = st.columns(5)
    for col,(icon,val,lbl,theme,delta) in zip(ic,[
        ("⚡",f"{st.session_state['total_kwh']:.1f} kWh","POWER SAVED",   "C-green",  f"+{round(cur['power_saved_watts']*15/60/1000,3)} kWh"),
        ("🌍",f"{st.session_state['total_co2']:.1f} kg", "CO₂ PREVENTED", "C-green",  f"+{round(co2['daily_carbon_saved_kg']/96,3)} kg"),
        ("🌱",f"{round(st.session_state['total_co2']/21,1)}","TREES/YEAR","C-teal",   None),
        ("💰",f"${round(st.session_state['total_kwh']*elec_cost,2)}","COST SAVED","C-amber",None),
        ("⏱️",f"{st.session_state['uptime']:,}h","UPTIME",            "C-violet", None),
    ]):
        with col: st.markdown(kpi(icon,val,lbl,theme,delta),unsafe_allow_html=True)

    st.markdown("<div style='height:18px'></div>",unsafe_allow_html=True)
    sec("LIVE SERVER STATUS","◉")
    lc = st.columns(6)
    sla_t = "C-green" if cur['sla_compliant'] else "C-rose"
    for col,(icon,val,lbl,theme) in zip(lc,[
        ("🖥️",f"{live['cpu']}%",             "CPU",       "C-sky"),
        ("🎮",f"{live['gpu']}%",             "GPU",       "C-violet"),
        ("🧠",f"{live['memory']}%",          "MEMORY",    "C-teal"),
        ("⚡",f"{live['power']}W",           "POWER",     "C-amber"),
        ("💾",f"{cur['power_saved_watts']}W","SAVED",     "C-green"),
        ("✅" if cur['sla_compliant'] else "⚠️",
              "OK" if cur['sla_compliant'] else "RISK","SLA",sla_t),
    ]):
        with col: st.markdown(kpi(icon,val,lbl,theme),unsafe_allow_html=True)

    st.markdown("<div style='height:18px'></div>",unsafe_allow_html=True)

    # ── Row 3: Allocation + Forecast ──────────────────────────────────────
    al,fc = st.columns([1,1.9])
    with al:
        st.markdown('<div class="panel">',unsafe_allow_html=True)
        sec("ALLOCATION","◫")
        st.markdown(
            pbr("CPU CORES",  cur['cpu_cores_allocated'],   total_cpu,    "pf-sky",    "sky",    f"{cur['cpu_cores_allocated']}/{total_cpu}")+
            pbr("GPU UNITS",  cur['gpu_units_allocated'],   total_gpu,    "pf-violet", "violet", f"{cur['gpu_units_allocated']}/{total_gpu}")+
            pbr("POWER DRAW", cur['estimated_power_watts'], power_budget, "pf-amber",  "amber",  f"{cur['estimated_power_watts']}W")+
            pbr("EFFICIENCY", cur['efficiency_gain_pct'],   100,          "pf-green",  "green",  f"{cur['efficiency_gain_pct']}%"),
            unsafe_allow_html=True)
        st.divider()
        m1,m2=st.columns(2)
        m1.metric("MODEL MAE",f"{model_m['mae']:.4f}")
        m2.metric("MODEL R²", f"{model_m['r2']:.4f}")
        st.markdown('</div>',unsafe_allow_html=True)

    with fc:
        sec("WORKLOAD HISTORY + AI FORECAST (24 h)","◎")
        recent = df.tail(96)
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=recent['timestamp'],y=recent['cpu_usage'],name='CPU %',
            fill='tozeroy',fillcolor='rgba(14,165,233,0.07)',
            line=dict(color='#0ea5e9',width=2.5),
            hovertemplate='<b>CPU</b>: %{y:.1f}%<extra></extra>'))
        fig.add_trace(go.Scatter(x=recent['timestamp'],y=recent['gpu_usage'],name='GPU %',
            fill='tozeroy',fillcolor='rgba(139,92,246,0.07)',
            line=dict(color='#8b5cf6',width=2.5),
            hovertemplate='<b>GPU</b>: %{y:.1f}%<extra></extra>'))
        fig.add_trace(go.Scatter(x=fdf['timestamp'],y=fdf['predicted_cpu'],name='AI Forecast',
            line=dict(color='#10b981',width=2.5,dash='dot'),mode='lines+markers',
            marker=dict(size=9,color='#10b981',symbol='diamond',line=dict(width=1.5,color='white')),
            hovertemplate='<b>Forecast</b>: %{y:.1f}%<extra></extra>'))
        fig.add_vrect(x0=fdf['timestamp'].iloc[0],x1=fdf['timestamp'].iloc[-1],
            fillcolor='rgba(16,185,129,0.05)',layer='below',line_width=0,
            annotation_text="FORECAST ZONE",
            annotation_font=dict(size=8,color='#94a3b8'),annotation_position="top left")
        fig.update_layout(**CH(360))
        st.plotly_chart(fig,use_container_width=True)

    st.markdown("<div style='height:12px'></div>",unsafe_allow_html=True)

    # ── Row 4: Power bars / Gauge / Carbon ───────────────────────────────
    p1,p2,p3 = st.columns([1.4,1,1])

    with p1:
        sec("NEXACORE vs STATIC POWER","⚡")
        daily=df.copy(); daily['date']=daily['timestamp'].dt.date
        dp=daily.groupby('date')['power_watts'].mean().reset_index()
        dp['static']  =cur['static_power_watts']
        dp['nexacore']=dp['power_watts']*0.75
        fig2=go.Figure()
        fig2.add_trace(go.Bar(x=dp['date'].astype(str),y=dp['static'],name='Static',
            marker=dict(color='rgba(239,68,68,0.55)',line=dict(color='rgba(239,68,68,0.8)',width=0.5)),
            hovertemplate='<b>Static</b>: %{y:.0f}W<extra></extra>'))
        fig2.add_trace(go.Bar(x=dp['date'].astype(str),y=dp['nexacore'],name='NEXACORE',
            marker=dict(color='rgba(16,185,129,0.65)',line=dict(color='rgba(16,185,129,0.9)',width=0.5)),
            hovertemplate='<b>NEXACORE</b>: %{y:.0f}W<extra></extra>'))
        fig2.update_layout(**CH(300,barmode='group'))
        st.plotly_chart(fig2,use_container_width=True)

    with p2:
        sec("EFFICIENCY GAUGE","◎")
        eff=cur['efficiency_gain_pct']
        fig_g=go.Figure(go.Indicator(
            mode="gauge+number+delta",value=eff,
            delta=dict(reference=20,increasing=dict(color='#10b981'),decreasing=dict(color='#ef4444'),font=dict(size=14)),
            number=dict(suffix='%',font=dict(family='Outfit',size=34,color='#059669')),
            gauge=dict(
                axis=dict(range=[0,80],tickfont=dict(size=8,color='#94a3b8'),tickcolor='#e2e8f0',dtick=20),
                bar=dict(color='rgba(16,185,129,0.85)',thickness=0.65),
                bgcolor='rgba(0,0,0,0)',borderwidth=0,
                steps=[
                    dict(range=[0,20],  color='rgba(239,68,68,0.06)'),
                    dict(range=[20,45], color='rgba(245,158,11,0.06)'),
                    dict(range=[45,80], color='rgba(16,185,129,0.06)'),
                ],
                threshold=dict(line=dict(color='#0ea5e9',width=2),thickness=0.8,value=eff),
            ),
        ))
        fig_g.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(family='JetBrains Mono',color='#94a3b8'),
            margin=dict(t=20,b=10,l=20,r=20),height=300)
        st.plotly_chart(fig_g,use_container_width=True)

    with p3:
        sec("CARBON BREAKDOWN","🌍")
        sv=co2['daily_carbon_saved_kg']
        fig3=go.Figure(go.Pie(
            labels=['Remaining CO₂','Stopped'],
            values=[max(50-sv,0.01),sv],
            hole=0.66,
            marker=dict(colors=['rgba(239,68,68,0.55)','rgba(16,185,129,0.7)'],
                        line=dict(color='rgba(0,0,0,0)',width=0)),
            textinfo='percent',textfont=dict(size=11,family='JetBrains Mono'),
            hovertemplate='<b>%{label}</b>: %{value:.2f} kg<extra></extra>',pull=[0,0.05]))
        fig3.add_annotation(text=f"<b>{co2['trees_equivalent_per_year']}</b><br>trees/yr",
            x=0.5,y=0.5,showarrow=False,
            font=dict(size=14,color='#059669',family='JetBrains Mono'))
        fig3.update_layout(**CH(300,
            showlegend=True,
            legend=dict(bgcolor='rgba(255,255,255,0.7)',orientation='h',y=-0.1,
                        font=dict(size=9),bordercolor='rgba(226,232,240,0.8)',borderwidth=1)))
        st.plotly_chart(fig3,use_container_width=True)

    st.markdown("<div style='height:12px'></div>",unsafe_allow_html=True)
    sec("UPCOMING ALLOCATION SCHEDULE","○")
    sdf=pd.DataFrame(sched)
    sdf['timestamp']    =sdf['timestamp'].dt.strftime('%H:%M')
    sdf['sla_compliant']=sdf['sla_compliant'].map({True:'✅ OK',False:'⚠️ Risk'})
    sdf=sdf[['timestamp','predicted_cpu','cpu_cores_allocated','gpu_units_allocated',
              'estimated_power_watts','power_saved_watts','efficiency_gain_pct','sla_compliant']]
    sdf.columns=['TIME','PRED CPU%','CPU CORES','GPU UNITS','POWER(W)','SAVED(W)','EFF%','SLA']
    st.dataframe(sdf,use_container_width=True,hide_index=True)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE: LIVE ANALYZER
# ══════════════════════════════════════════════════════════════════════════════
elif st.session_state['page'] == 'LIVE ANALYZER':
    sec("REAL-TIME SERVER MONITOR","◉")
    m1,m2,m3,m4=st.columns(4)
    m1.metric("CPU",   f"{live['cpu']}%",   delta=f"{round(live['cpu']-50,1)}%",  delta_color="inverse")
    m2.metric("GPU",   f"{live['gpu']}%",   delta=f"{round(live['gpu']-35,1)}%",  delta_color="inverse")
    m3.metric("MEMORY",f"{live['memory']}%")
    m4.metric("POWER", f"{live['power']}W", delta=f"−{cur['power_saved_watts']}W",delta_color="inverse")
    st.markdown("<div style='height:16px'></div>",unsafe_allow_html=True)

    if len(lh) > 1:
        la,lb=st.columns([1.6,1])
        with la:
            sec("CPU / GPU / MEMORY TREND","◈")
            fig_l=go.Figure()
            for cn,clr,fill,nm in [
                ('cpu','#0ea5e9','rgba(14,165,233,0.1)','CPU %'),
                ('gpu','#8b5cf6','rgba(139,92,246,0.1)','GPU %'),
                ('mem','#10b981','rgba(16,185,129,0.1)','MEM %'),
            ]:
                fig_l.add_trace(go.Scatter(x=lh['time'],y=lh[cn],name=nm,
                    fill='tozeroy',fillcolor=fill,line=dict(color=clr,width=2.5),
                    hovertemplate=f'<b>{nm}</b>: %{{y:.1f}}%<extra></extra>'))
            fig_l.update_layout(**CH(340))
            st.plotly_chart(fig_l,use_container_width=True)

        with lb:
            sec("RESOURCE RADAR","◎")
            cats=['CPU','GPU','MEM','PWR','EFF']
            vr=[live['cpu'],live['gpu'],live['memory'],
                min(live['power']/power_budget*100,100),cur['efficiency_gain_pct']]
            fig_r=go.Figure(go.Scatterpolar(
                r=vr+[vr[0]],theta=cats+[cats[0]],
                fill='toself',fillcolor='rgba(14,165,233,0.1)',
                line=dict(color='#0ea5e9',width=2.5),
                marker=dict(color='#0ea5e9',size=9,line=dict(color='white',width=1.5)),
                hovertemplate='<b>%{theta}</b>: %{r:.1f}%<extra></extra>'))
            fig_r.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                font=dict(family='JetBrains Mono',color='#94a3b8',size=9),
                margin=dict(t=20,b=20,l=20,r=20),height=340,
                polar=dict(
                    bgcolor='rgba(248,250,252,0.8)',
                    radialaxis=dict(visible=True,range=[0,100],color='#cbd5e1',
                        gridcolor='rgba(226,232,240,0.9)',tickfont=dict(size=8)),
                    angularaxis=dict(color='#94a3b8',gridcolor='rgba(226,232,240,0.9)',
                        tickfont=dict(size=9))),
                hoverlabel=dict(bgcolor='#fff',bordercolor='#e2e8f0',
                    font=dict(family='JetBrains Mono',size=11,color='#0f172a')))
            st.plotly_chart(fig_r,use_container_width=True)

        sec("POWER SAVED PER CYCLE (W)","⚡")
        fig_p=go.Figure()
        fig_p.add_trace(go.Bar(x=lh['time'],y=lh['saved'],name='Saved',
            marker=dict(
                color=lh['saved'],
                colorscale=[[0,'rgba(239,68,68,0.7)'],[0.4,'rgba(245,158,11,0.7)'],[1,'rgba(16,185,129,0.8)']],
                showscale=True,
                colorbar=dict(thickness=8,tickfont=dict(size=8,color='#94a3b8'),
                    title=dict(text='W',font=dict(size=8,color='#94a3b8'),side='right'))),
            hovertemplate='<b>%{x}</b>: %{y:.1f}W saved<extra></extra>'))
        fig_p.add_trace(go.Scatter(x=lh['time'],y=lh['saved'],mode='lines',
            line=dict(color='rgba(16,185,129,0.4)',width=1.5,dash='dot'),
            showlegend=False,hoverinfo='skip'))
        fig_p.update_layout(**CH(260))
        st.plotly_chart(fig_p,use_container_width=True)

        with st.expander("📊 Raw Live Data"):
            st.dataframe(lh.iloc[::-1].reset_index(drop=True),use_container_width=True)
    else:
        st.info("⏳ Click **↺ Refresh** a few times to populate live charts.")

# ══════════════════════════════════════════════════════════════════════════════
# PAGE: DATABASES
# ══════════════════════════════════════════════════════════════════════════════
elif st.session_state['page'] == 'DATABASES':
    sec("DATABASE CONNECTIONS","▣")
    d1,d2,d3,d4=st.columns(4)
    d1.metric("TOTAL","6"); d2.metric("ONLINE","5",delta="Healthy")
    d3.metric("RECORDS","~44.1M"); d4.metric("AVG LATENCY","4.2ms")
    st.markdown("<div style='height:16px'></div>",unsafe_allow_html=True)

    dbs=[
        {"name":"WorkloadDB-Primary",  "type":"Time-Series","host":"amd-epyc-node-01", "status":"Online", "records":"2.4M", "latency":3,   "sync":"Just now"},
        {"name":"HistoricalDB-Archive","type":"Structured", "host":"amd-epyc-node-02", "status":"Online", "records":"18.7M","latency":8,   "sync":"2 min ago"},
        {"name":"CarbonMetrics-DB",    "type":"Analytics",  "host":"amd-epyc-node-03", "status":"Online", "records":"890K", "latency":5,   "sync":"Just now"},
        {"name":"SLA-MonitorDB",       "type":"Relational", "host":"amd-epyc-node-01", "status":"Online", "records":"1.1M", "latency":4,   "sync":"1 min ago"},
        {"name":"RealtimeStream-DB",   "type":"Stream",     "host":"amd-instinct-gpu1","status":"Online", "records":"Live", "latency":1,   "sync":"Live"},
        {"name":"BackupDB-Replica",    "type":"Backup",     "host":"amd-epyc-node-04", "status":"Standby","records":"21M",  "latency":None,"sync":"10 min ago"},
    ]
    dc1,dc2=st.columns(2)
    for i,db in enumerate(dbs):
        col=dc1 if i%2==0 else dc2
        scls="st-on" if db['status']=='Online' else "st-stb"
        icon="🟢" if db['status']=='Online' else "🟡"
        lat=f"{db['latency']}ms" if db['latency'] else "—"
        with col:
            st.markdown(f"""<div class="dbc">
              <div class="dbc-name">{db['name']}</div>
              <div class="dbc-grid">
                <div class="dbc-cell"><b>Status</b><span class="{scls}">{icon} {db['status']}</span></div>
                <div class="dbc-cell"><b>Type</b>{db['type']}</div>
                <div class="dbc-cell"><b>Host</b>{db['host']}</div>
                <div class="dbc-cell"><b>Records</b>{db['records']}</div>
                <div class="dbc-cell"><b>Latency</b>{lat}</div>
                <div class="dbc-cell"><b>Sync</b>{db['sync']}</div>
              </div>
            </div>""",unsafe_allow_html=True)

    st.markdown("<div style='height:16px'></div>",unsafe_allow_html=True)
    gc1,gc2=st.columns(2)
    with gc1:
        sec("LATENCY (ms)","⚡")
        lnames=[d['name'] for d in dbs if d['latency']]
        lvals =[d['latency'] for d in dbs if d['latency']]
        lclrs =['#10b981' if l<=3 else '#f59e0b' if l<=6 else '#ef4444' for l in lvals]
        fig_lt=go.Figure(go.Bar(x=lnames,y=lvals,marker_color=lclrs,
            text=[f"{l}ms" for l in lvals],textposition='outside',
            textfont=dict(color='#94a3b8',size=9),
            hovertemplate='<b>%{x}</b>: %{y}ms<extra></extra>'))
        fig_lt.update_layout(**CH(280,yaxis_title="ms"))
        st.plotly_chart(fig_lt,use_container_width=True)

    with gc2:
        sec("RECORD COUNTS (millions)","◈")
        rnames=[d['name'] for d in dbs if d['records']!='Live']
        rvals =[float(d['records'].replace('M','').replace('K',''))/
                (1 if 'M' in d['records'] else 1000) for d in dbs if d['records']!='Live']
        fig_rc=go.Figure(go.Bar(x=rnames,y=rvals,
            marker=dict(color=rvals,
                colorscale=[[0,'rgba(14,165,233,0.4)'],[1,'rgba(139,92,246,0.8)']]),
            text=[f"{v:.1f}M" for v in rvals],textposition='outside',
            textfont=dict(color='#94a3b8',size=9),
            hovertemplate='<b>%{x}</b>: %{y:.2f}M<extra></extra>'))
        fig_rc.update_layout(**CH(280,yaxis_title="Million Records"))
        st.plotly_chart(fig_rc,use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE: AI ASSISTANT
# ══════════════════════════════════════════════════════════════════════════════
elif st.session_state['page'] == 'AI ASSISTANT':
    sec("NEXACORE AI — FULLY OFFLINE · NO API KEY NEEDED","◎")

    def get_reply(user_q):
        q=user_q.lower().strip()
        tkwh=st.session_state['total_kwh']
        tco2=st.session_state['total_co2']
        upt =st.session_state['uptime']
        if any(w in q for w in ['cpu','processor','core']):
            cs="HIGH ⚠️" if live['cpu']>75 else("NORMAL ✅" if live['cpu']>30 else "LOW 💤")
            tip=("Scale down idle cores to save power." if live['cpu']<30
                 else "CPU is hot — NEXACORE is redistributing load." if live['cpu']>75
                 else "CPU is in the optimal range.")
            return(f"🖥️ CPU: {live['cpu']}% — {cs}\n\n• Cores: {cur['cpu_cores_allocated']}/{total_cpu}\n"
                   f"• Utilization: {cur['cpu_utilization_pct']}%\n"
                   f"• SLA: {'✅ OK' if cur['sla_compliant'] else '⚠️ AT RISK'}\n\n💡 {tip}")
        elif any(w in q for w in ['gpu','graphics','instinct']):
            return(f"🎮 GPU: {live['gpu']}%\n\n• Units: {cur['gpu_units_allocated']}/{total_gpu}\n"
                   f"• Utilization: {cur['gpu_utilization_pct']}%\n• AMD Instinct GPUs power the ML pipeline\n\n"
                   f"💡 GPU units scale dynamically based on predicted demand.")
        elif any(w in q for w in ['memory','ram','mem']):
            return(f"🧠 Memory: {live['memory']}%\n\n"
                   f"• Status: {'⚠️ HIGH' if live['memory']>85 else '✅ Normal'}\n\n"
                   f"💡 Memory trends feed into the workload forecast model.")
        elif any(w in q for w in ['power','watt','energy']):
            return(f"⚡ Power:\n\n• Draw: {live['power']}W\n• Static: {cur['static_power_watts']}W\n"
                   f"• Saving: {cur['power_saved_watts']}W ({cur['efficiency_gain_pct']}%)\n"
                   f"• Budget: {power_budget}W\n• Daily saved: {co2['daily_energy_saved_kwh']} kWh\n\n"
                   f"💡 NEXACORE eliminates waste proactively, not reactively.")
        elif any(w in q for w in ['co2','carbon','emission','tree','green']):
            return(f"🌍 Carbon:\n\n• Daily stopped: {co2['daily_carbon_saved_kg']} kg\n"
                   f"• Annual stopped: {co2['annual_carbon_saved_kg']} kg\n"
                   f"• Total since deploy: {tco2:.1f} kg\n"
                   f"• Trees/year equiv: {co2['trees_equivalent_per_year']}\n"
                   f"• Annual cost saved: ${co2['annual_cost_saved_usd']}\n\n"
                   f"🌱 Each cycle prevents more CO₂ from being emitted.")
        elif any(w in q for w in ['cost','money','saving','dollar','bill']):
            return(f"💰 Savings:\n\n• Daily: ${co2['daily_cost_saved_usd']}\n"
                   f"• Annual: ${co2['annual_cost_saved_usd']}\n"
                   f"• Total: ${round(tkwh*elec_cost,2)}\n• kWh saved: {tkwh:.1f}\n\n"
                   f"💡 Pure savings from smarter scheduling — zero hardware changes.")
        elif any(w in q for w in ['ml','model','machine','predict','forecast','r2','mae','algorithm']):
            return(f"🧠 ML Model:\n\n• Algorithm: Ridge Regression + lag features\n"
                   f"• Look-back: 12 steps = 3 hours\n"
                   f"• Horizon: {forecast_steps} steps = {forecast_steps*15} min\n"
                   f"• MAE: {model_m['mae']:.4f}\n• R²: {model_m['r2']:.4f}\n\n"
                   f"💡 Predicts 2 hours ahead — acts before spikes, not after.")
        elif any(w in q for w in ['sla','service','compliance']):
            return(f"📋 SLA: {'✅ COMPLIANT' if cur['sla_compliant'] else '⚠️ AT RISK'}\n\n"
                   f"• Power: {cur['estimated_power_watts']}W / {power_budget}W\n"
                   f"• 15% headroom maintained\n• Uptime: {upt} hours\n\n"
                   f"💡 SLA guaranteed even at maximum efficiency settings.")
        elif any(w in q for w in ['database','db','connect']):
            return("🗄️ Databases:\n\n• Total: 6 · Online: 5 ✅ · Standby: 1 🟡\n"
                   "• Records: ~44.1M · Avg latency: 4.2ms\n\n"
                   "DBs: WorkloadDB · HistoricalDB · CarbonMetrics\n    SLA-Monitor · RealtimeStream · BackupDB")
        elif any(w in q for w in ['amd','epyc','instinct','hardware']):
            return(f"🔴 AMD Hardware:\n\n• EPYC — {total_cpu} cores, multi-node\n"
                   f"• Instinct GPUs — {total_gpu} units for ML\n"
                   f"• Fine-grained per-core power scaling\n"
                   f"• Instinct accelerates real-time prediction")
        elif any(w in q for w in ['tip','optim','reduce','improve','suggest']):
            tips=[]
            if live['cpu']<35:    tips.append(f"• CPU at {live['cpu']}% — scale down to save ~64W")
            if live['gpu']<30:    tips.append(f"• GPU at {live['gpu']}% — suspend 1–2 units")
            if live['memory']>80: tips.append(f"• Memory at {live['memory']}% — check for leaks")
            tips+=["• Shift batch jobs to off-peak hours (midnight–6am)",
                   "• Enable auto-refresh for continuous optimization",
                   "• 1°C cooling setpoint increase → ~4% power saving"]
            return "💡 Optimization Tips:\n\n"+"\n".join(tips)
        elif any(w in q for w in ['hello','hi','hey']):
            return(f"⚡ NEXACORE AI online.\n\nSnapshot:\n"
                   f"• CPU: {live['cpu']}% | GPU: {live['gpu']}% | MEM: {live['memory']}%\n"
                   f"• Saving: {cur['power_saved_watts']}W vs static\n"
                   f"• CO₂ stopped today: {co2['daily_carbon_saved_kg']} kg\n\nWhat would you like to explore?")
        elif any(w in q for w in ['help','topic','what can']):
            return("🤖 Topics:\n\ncpu · gpu · memory · power · co2\ncost · ml model · sla · database\namd hardware · optimization tips")
        elif any(w in q for w in ['thank','great','nice','awesome','good']):
            return "😊 Always optimizing. Ask me anything else!"
        else:
            return(f"🤔 Snapshot: CPU {live['cpu']}% | GPU {live['gpu']}% | MEM {live['memory']}%\n"
                   f"Saving {cur['power_saved_watts']}W | CO₂ {co2['daily_carbon_saved_kg']} kg/day\n\n"
                   f"Try: cpu · gpu · power · co2 · cost · ml · help")

    for msg in st.session_state['chat']:
        if msg['role']=='bot':
            txt=msg['text'].replace('\n','<br>')
            st.markdown(f"""<div class="cw">
              <div style="display:flex;gap:10px;align-items:flex-start">
                <div style="width:30px;height:30px;border-radius:50%;flex-shrink:0;background:linear-gradient(135deg,#0284c7,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:.85rem">⚡</div>
                <div><div class="cm-b">{txt}</div><div class="cm-t">NEXACORE AI · {msg['time']}</div></div>
              </div></div>""",unsafe_allow_html=True)
        else:
            st.markdown(f"""<div class="cw" style="text-align:right">
              <div class="cm-u">{msg['text']}</div>
              <div class="cm-t">You · {msg['time']}</div>
            </div>""",unsafe_allow_html=True)

    st.markdown("<div style='height:10px'></div>",unsafe_allow_html=True)
    q1=st.columns(4)
    for i,(c,q) in enumerate(zip(q1,["Power usage?","CO₂ saved?","ML model?","Optimize tips"])):
        with c:
            if st.button(q,key=f"q1{i}",use_container_width=True): st.session_state['_pq']=q; st.rerun()
    q2=st.columns(4)
    for i,(c,q) in enumerate(zip(q2,["CPU status","Database status","SLA status","AMD hardware"])):
        with c:
            if st.button(q,key=f"q2{i}",use_container_width=True): st.session_state['_pq']=q; st.rerun()

    with st.form("cf",clear_on_submit=True):
        fi,fb=st.columns([6,1])
        with fi: ui=st.text_input("","",placeholder="Ask anything about your data center…",label_visibility="collapsed")
        with fb: sub=st.form_submit_button("Send ➤",use_container_width=True)
    if '_pq' in st.session_state: ui=st.session_state['_pq']; sub=True; del st.session_state['_pq']
    if sub and ui and ui.strip():
        st.session_state['chat'].append({'role':'user','text':ui.strip(),'time':datetime.now().strftime('%H:%M')})
        st.session_state['chat'].append({'role':'bot','text':get_reply(ui.strip()),'time':datetime.now().strftime('%H:%M')})
        st.rerun()
    if len(st.session_state['chat'])>1:
        if st.button("🗑️ Clear chat"): st.session_state['chat']=[st.session_state['chat'][0]]; st.rerun()

# ══════════════════════════════════════════════════════════════════════════════
# PAGE: FEEDBACK
# ══════════════════════════════════════════════════════════════════════════════
elif st.session_state['page'] == 'FEEDBACK':
    sec("USER FEEDBACK & RATINGS","◆")
    fl,fr=st.columns([1,1.3])
    with fl:
        sec("SUBMIT FEEDBACK","✏️")
        fb_name  =st.text_input("Name",placeholder="e.g. Rajender Reddy")
        fb_dept  =st.selectbox("Department",["Engineering","Operations","Management","Research","Other"])
        fb_rating=st.select_slider("Rating",options=[1,2,3,4,5],value=5,format_func=lambda x:"★"*x+f"  ({x}/5)")
        fb_cat   =st.selectbox("Category",["General","Energy Savings","Dashboard UI","AI Features","Performance"])
        fb_text  =st.text_area("Feedback",placeholder="Your experience with NEXACORE…",height=100)
        if st.button("📤  Submit Feedback",use_container_width=True):
            if fb_name.strip() and fb_text.strip():
                st.session_state['feedback'].insert(0,{'user':fb_name.strip(),'dept':fb_dept,
                    'rating':fb_rating,'cat':fb_cat,'text':fb_text.strip(),'time':'Just now'})
                st.success("✅ Submitted!"); st.balloons()
            else: st.warning("Please fill in name and feedback.")
        st.markdown("<div style='height:14px'></div>",unsafe_allow_html=True)
        sec("RATING DISTRIBUTION","📊")
        ratings=[f['rating'] for f in st.session_state['feedback']]
        rc={i:ratings.count(i) for i in range(1,6)}
        fig_rb=go.Figure(go.Bar(
            x=["★★★★★","★★★★","★★★","★★","★"],
            y=[rc[i] for i in range(5,0,-1)],
            marker=dict(color=['#10b981','#34d399','#f59e0b','#fb923c','#ef4444']),
            text=[rc[i] for i in range(5,0,-1)],textposition='outside',
            textfont=dict(color='#94a3b8',size=10),
            hovertemplate='%{x}: %{y} reviews<extra></extra>'))
        fig_rb.update_layout(**CH(200,showlegend=False))
        st.plotly_chart(fig_rb,use_container_width=True)

    with fr:
        ratings=[f['rating'] for f in st.session_state['feedback']]
        avg=sum(ratings)/len(ratings) if ratings else 0
        sec(f"RECENT  ·  AVG {'★'*round(avg)} {avg:.1f}/5  ·  {len(ratings)} reviews","💬")
        for fb in st.session_state['feedback'][:7]:
            cat=fb.get('cat','General'); dept=fb.get('dept','Engineering')
            st.markdown(f"""<div class="fbc">
              <div class="fbc-user">{"★"*fb['rating']} &nbsp; {fb['user']}
                <span style="color:#cbd5e1;font-family:'JetBrains Mono';font-size:.6rem"> · {dept}</span>
              </div>
              <div style="display:inline-block;background:rgba(14,165,233,0.08);color:#0284c7;
                font-family:'JetBrains Mono';font-size:.58rem;padding:2px 10px;border-radius:20px;
                margin-top:6px;letter-spacing:1px">{cat.upper()}</div>
              <div class="fbc-text">{fb['text']}</div>
              <div class="fbc-foot">◉ {fb['time']}</div>
            </div>""",unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# FOOTER
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div style="text-align:center;padding:22px 0 6px;border-top:1.5px solid rgba(226,232,240,0.9);margin-top:32px">
  <span style="font-family:'JetBrains Mono',monospace;font-size:.58rem;color:#cbd5e1;letter-spacing:2px">
    NEXACORE &nbsp;·&nbsp; AMD SLINGSHOT PROJECT &nbsp;·&nbsp; PYTHON &nbsp;·&nbsp; STREAMLIT &nbsp;·&nbsp; SCIKIT-LEARN &nbsp;·&nbsp; PLOTLY
  </span>
</div>""",unsafe_allow_html=True)

if auto_ref:
    time.sleep(5); st.rerun()
