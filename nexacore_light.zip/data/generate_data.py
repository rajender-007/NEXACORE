import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_workload_data(days=30, interval_minutes=15):
    """Generate realistic simulated server workload data."""
    periods = int(days * 24 * 60 / interval_minutes)
    timestamps = [datetime.now() - timedelta(minutes=interval_minutes * i) for i in range(periods, 0, -1)]

    np.random.seed(42)
    hours = np.array([t.hour for t in timestamps])
    day_of_week = np.array([t.weekday() for t in timestamps])

    # Simulate realistic CPU usage with daily patterns
    base_cpu = 30 + 35 * np.sin((hours - 6) * np.pi / 12) * (hours >= 6) * (hours <= 22)
    weekend_factor = np.where(day_of_week >= 5, 0.6, 1.0)
    cpu_usage = np.clip(base_cpu * weekend_factor + np.random.normal(0, 5, periods), 5, 100)

    # GPU usage correlated with CPU but different pattern
    gpu_usage = np.clip(cpu_usage * 0.7 + np.random.normal(0, 8, periods), 0, 100)

    # Memory usage
    memory_usage = np.clip(40 + 0.3 * cpu_usage + np.random.normal(0, 3, periods), 20, 95)

    # Power consumption (Watts) based on resource usage
    power = 200 + 3.5 * cpu_usage + 2.0 * gpu_usage + 0.5 * memory_usage + np.random.normal(0, 10, periods)

    df = pd.DataFrame({
        'timestamp': timestamps,
        'cpu_usage': np.round(cpu_usage, 2),
        'gpu_usage': np.round(gpu_usage, 2),
        'memory_usage': np.round(memory_usage, 2),
        'power_watts': np.round(power, 2),
        'active_tasks': np.random.randint(5, 80, periods),
        'hour': hours,
        'day_of_week': day_of_week
    })
    return df

def get_live_snapshot():
    """Simulate a live server snapshot."""
    hour = datetime.now().hour
    base = 30 + 35 * np.sin((hour - 6) * np.pi / 12) if 6 <= hour <= 22 else 15
    cpu = float(np.clip(base + np.random.normal(0, 5), 5, 100))
    gpu = float(np.clip(cpu * 0.7 + np.random.normal(0, 8), 0, 100))
    mem = float(np.clip(40 + 0.3 * cpu + np.random.normal(0, 3), 20, 95))
    power = float(200 + 3.5 * cpu + 2.0 * gpu + 0.5 * mem)
    return {'cpu': round(cpu, 1), 'gpu': round(gpu, 1), 'memory': round(mem, 1), 'power': round(power, 1)}
